# Tubes1TBFO-SholehToTheMax
- Spesifikasinya ada di link https://docs.google.com/document/d/1Te3TjxvMsjGSek1sFNQm1gMwnQhB4o2JZIFb8brC_KQ/edit
- Menggunakan interpreter python 3
- Untuk menjalankan program, ketik: > python Main.py