# file: State.py, tempat menyimpan struktur data dari state DFA yang diberikan
# @Sholeh To The Max : Fabian Zhafransyah - 13518022, Kevin Rizki Mohammad - 13518100
# 30 Sep 2019
# TUGAS BESAR TEORI BAHASA FORMAL DAN AUTOMATA 1
# THE SIMS SIMULATOR, Link: https://docs.google.com/document/d/1Te3TjxvMsjGSek1sFNQm1gMwnQhB4o2JZIFb8brC_KQ/edit

''' Atribut yang merepresentasikan state pada suatu waktu '''
'''  Nilai diinisiasi sesuai dengan start state pada DFA  '''
hygiene = int(0)
energy = int(10)
fun = int(0)